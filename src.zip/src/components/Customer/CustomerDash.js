import React from "react";


import './Deposit.css';
import "bootstrap/dist/css/bootstrap.min.css";
import CustNavBar from "./Custnavbar";

function Customerdash()

{ 
    
    return(
    <><CustNavBar/>
    <h3>WELCOME!!!!</h3></>

);

}
export default Customerdash;