import React from "react";



import "bootstrap/dist/css/bootstrap.min.css";
import ManagerNavBar from "./Managernavbar";


function MangerDash()

{ 
    
    return(
    <><ManagerNavBar/>
    <h3>WELCOME!!!!</h3></>

);

}
export default MangerDash;