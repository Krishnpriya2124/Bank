import React from "react";



import "bootstrap/dist/css/bootstrap.min.css";
import StaffNavBar from "./Staffnavbar";


function Staffdash()

{ 
    
    return(
    <><StaffNavBar/>
    <h3>WELCOME!!!!</h3></>

);

}
export default Staffdash;